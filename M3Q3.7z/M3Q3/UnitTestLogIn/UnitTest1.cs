﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace UnitTestLogIn
{
    [TestClass]
    public class UnitTest1
    {
        //[TestMethod]
        //public void TestMethod1()
        //{
        //    IWebDriver driver = new ChromeDriver();
        //    driver.Navigate().GoToUrl("http://localhost:51109/WebForm1.aspx");
        //    IWebElement username = driver.FindElement(By.Id("TextBox1"));
        //    IWebElement password = driver.FindElement(By.Id("TextBox2"));
        //    username.SendKeys("Vijaya");
        //    password.SendKeys("laxmi");
        //    IWebElement chk = driver.FindElement(By.CssSelector("input[id='CheckBox1']"));
        //    chk.Click();
        //    string str = username.GetAttribute("value");

        //}


        [TestMethod]
        public void TestMethod1()
        {
            IWebDriver driver = new ChromeDriver();
            driver.Navigate().GoToUrl("http://localhost:51109/WebForm1.aspx");
            IWebElement username = driver.FindElement(By.Id("TextBox1"));
            username.SendKeys("Vijaya");
            string str = username.GetAttribute("value");
            Assert.AreEqual("Vijaya", str);
            driver.Close();
            driver.Quit();
        }
        [TestMethod]
        public void TestMethod3()
        {
            IWebDriver driver = new ChromeDriver();
            driver.Navigate().GoToUrl("http://localhost:51109/WebForm1.aspx");
            IWebElement password = driver.FindElement(By.Id("TextBox2"));
            password.SendKeys("Vijaya");
            string str = password.GetAttribute("value");
            Assert.AreEqual("Vijaya",str);
            driver.Close();
            driver.Quit();
        }
        [TestMethod]
        public void ValidateCheckBox()
        {
            IWebDriver driver = new ChromeDriver();
            driver.Navigate().GoToUrl("http://localhost:51109/WebForm1.aspx");
            IWebElement chk = driver.FindElement(By.Id("CheckBox1"));
            chk.Click();
            Assert.AreEqual(true,chk.Selected);
            driver.Close();
            driver.Quit();
        }

        [TestMethod]
        public void EmptyUserName()
        {
            IWebDriver driver = new ChromeDriver();
            driver.Navigate().GoToUrl("http://localhost:51109/WebForm1.aspx");
            IWebElement username = driver.FindElement(By.Id("TextBox1"));
            username.SendKeys("");
            string str = username.GetAttribute("value");
            Assert.AreEqual("", str);
            driver.Close();
            driver.Quit();
        }
        [TestMethod]
        public void EmptyPasswordValidation()
        {
            IWebDriver driver = new ChromeDriver();
            driver.Navigate().GoToUrl("http://localhost:51109/WebForm1.aspx");
            IWebElement password = driver.FindElement(By.Id("TextBox2"));
            password.SendKeys("");
            string str = password.GetAttribute("value");
            Assert.AreEqual("", str);
            driver.Close();
            driver.Quit();
        }
        [TestMethod]
        public void ValidateEmptyCheckBox()
        {
            IWebDriver driver = new ChromeDriver();
            driver.Navigate().GoToUrl("http://localhost:51109/WebForm1.aspx");
            IWebElement chk = driver.FindElement(By.Id("CheckBox1"));
            
            Assert.AreEqual(false, chk.Selected);
            driver.Close();
            driver.Quit();
        }

        [TestMethod]
        public void ValidateUserName()
        {
            string Url = "http://localhost:51109/WebForm1.aspx";
            IWebDriver driver = new ChromeDriver();
            driver.Navigate().GoToUrl(Url);
            driver.Manage().Window.Maximize();
            driver.FindElement(By.Id("TextBox1")).SendKeys("");

            driver.FindElement(By.Id("Button1")).Click();

            IWebElement webElement = driver.FindElement(By.Id("Valusername"));
            string txt = webElement.Text;
            Assert.AreEqual("enter user name", txt);
            
        }

        [TestMethod]
        public void ValidatePassword()
        {
            string Url = "http://localhost:51109/WebForm1.aspx";
            IWebDriver driver = new ChromeDriver();
            driver.Navigate().GoToUrl(Url);
            driver.Manage().Window.Maximize();
            driver.FindElement(By.Id("TextBox2")).SendKeys("");
            driver.FindElement(By.Id("Button1")).Click();
            IWebElement webElement = driver.FindElement(By.Id("ValPassword"));
            string txt = webElement.Text;
            Assert.AreEqual("enter password", txt);
          
        }
        [TestMethod]
        public void ValidateAge()
        {
            string Url = "http://localhost:51109/WebForm1.aspx";
            IWebDriver driver = new ChromeDriver();
            driver.Navigate().GoToUrl(Url);
            driver.Manage().Window.Maximize();
            IWebElement webElementAge = driver.FindElement(By.Id("TextBox3"));
            webElementAge.SendKeys("99");
            driver.FindElement(By.Id("Button1")).Click();
            
            IWebElement webElement = driver.FindElement(By.Id("ValAge"));
       
            string txt = webElement.Text;
            Assert.AreEqual("Age should be in between 18 and 60", txt);

        }
        [TestMethod]
        public void ValidatePhoneNumber()
        {
            string Url = "http://localhost:51109/WebForm1.aspx";
            IWebDriver driver = new ChromeDriver();
            driver.Navigate().GoToUrl(Url);
            driver.Manage().Window.Maximize();
            IWebElement webElementAge = driver.FindElement(By.Id("TextBox4"));
            webElementAge.SendKeys("564546346");
            driver.FindElement(By.Id("Button1")).Click();

            IWebElement webElement = driver.FindElement(By.Id("ValPhoneNumber"));

            string txt = webElement.Text;
            Assert.AreEqual("Phone Number should be in correct format", txt);

        }

    }
}
